package com.example.taller1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<producto> Listaprincipalproducto;
    private RecyclerView rvListadoProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cargarDatos();

        rvListadoProductos = findViewById(R.id.rv_listado_productos);

        AdaptadorPersonalizado miAdaptador = new AdaptadorPersonalizado(Listaprincipalproducto);

        miAdaptador.setOnItemClickListener(new AdaptadorPersonalizado.OnItemClickListener() {
            @Override
            public void onItemClick(Producto producto, int posicion) {
                Toast.makeText(MainActivity.this, "Hice Click desde Activity"+producto.getNombre(), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onItembtnEraseClick(producto producto, int posicion) {
                Listaprincipalproducto.remove(posicion);
                miAdaptador.setListinfo(Listaprincipalproducto);
            }
        }

        rvListadoProductos.setAdapter(miAdaptador);
        rvListadoProductos.setLayoutManager(new LinearLayoutManager(this));
    }

    public void cargarDatos(){
        producto producto1 = new producto();
        producto1.setNombre("Computador HP");
        producto1.setPrecio(1749000.00);
        producto1.setUrlimagen("https://panamericana.vtexassets.com/arquivos/ids/447432-1200-auto?v=637935138505970000&width=1200&height=auto&aspect=true");

        producto producto2 = new producto();
        producto2.setNombre("Apple iPhone 9");
        producto2.setPrecio(4500000.00);
        producto1.setUrlimagen("https://cdn.shopify.com/s/files/1/0604/8373/1606/products/IMG-7380043_823x.jpg?v=1673373173");

        Listaprincipalproducto = new ArrayList<>();
        Listaprincipalproducto.add(producto1);
        Listaprincipalproducto.add(producto2);

    }
}